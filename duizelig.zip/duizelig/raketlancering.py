a = 30
while a >= 0:
    print(a)
    a = a - 1
print('lancering')
    