nummer = 50
while nummer < 1001:
    print(nummer)
    nummer = nummer + 1