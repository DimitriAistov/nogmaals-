a = 1
while a <= 12:
    print(a, 'am')
    a = a + 1

b = 1
while b <= 12:
    print(b, 'pm')
    b = b + 1