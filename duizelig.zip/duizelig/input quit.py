a = 1
invoer = ''

while invoer != 'quit':
    invoer = input('schrijf quit ')
