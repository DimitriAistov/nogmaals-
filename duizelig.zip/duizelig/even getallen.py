a = 20
while a <= 50:
    print(a)
    a = a + 2